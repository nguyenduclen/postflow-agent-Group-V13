package vn.phutungmaykubota.postflowagent;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public final class AgentSync {
    private static final String PREFS = "postflow_agent_final";
    private static final String DEFAULT_SERVER =
            "https://postflow.phutungmaykubota.vn";

    private AgentSync() {}

    public static String server(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String s = p.getString("server", DEFAULT_SERVER);
        if (s == null) s = DEFAULT_SERVER;
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    public static String token(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("agent_token", "");
    }

    public static String deviceId(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("device_id", "");
    }

    public static Result heartbeat(Context context) {
        String token = token(context);
        if (token == null || token.trim().isEmpty()) {
            return new Result(false, 0, "Chưa có mã ghép nối Agent.");
        }

        HttpURLConnection c = null;
        try {
            String endpoint = server(context) + "/agent_api.php";
            URL u = new URL(endpoint);
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("X-Agent-Token", token);

            boolean chrome = PostFlowAccessibilityService.isChromeActive();
            boolean facebook = PostFlowAccessibilityService.isFacebookActive();
            String url = PostFlowAccessibilityService.lastUrl == null
                    ? "" : PostFlowAccessibilityService.lastUrl;
            String pageName = PostFlowAccessibilityService.currentPageName();
            String pageId = PostFlowAccessibilityService.currentPageId();
            String pageUrl = PostFlowAccessibilityService.currentPageUrl();
            String mode = PostFlowAccessibilityService.currentFacebookMode();
            String groupsJson = PostFlowAccessibilityService.currentVisibleGroupsJson();
            String groupOwnerType = "PROFILE".equalsIgnoreCase(mode) ? "PROFILE"
                    : (PostFlowAccessibilityService.isPageDetected() ? "PAGE" : "");
            String pkg = chrome
                    ? "com.android.chrome"
                    : (PostFlowAccessibilityService.lastPackage == null
                        ? "" : PostFlowAccessibilityService.lastPackage);

            String body =
                    "device_id=" + enc(deviceId(context)) +
                    "&chrome_active=" + (chrome ? "1" : "0") +
                    "&facebook_detected=" + (facebook ? "1" : "0") +
                    "&facebook_url=" + enc(facebook ? url : "") +
                    "&package_name=" + enc(pkg) +
                    "&page_detected=" + (PostFlowAccessibilityService.isPageDetected() ? "1" : "0") +
                    "&page_name=" + enc(pageName) +
                    "&page_id=" + enc(pageId) +
                    "&page_url=" + enc(pageUrl) +
                    "&facebook_mode=" + enc(mode) +
                    "&group_owner_type=" + enc(groupOwnerType) +
                    "&visible_groups_json=" + enc(groupsJson) +
                    "&groups_json=" + enc(groupsJson) +
                    "&group_count=" + countGroups(groupsJson);

            byte[] bytes = body.getBytes("UTF-8");
            c.getOutputStream().write(bytes);
            c.getOutputStream().flush();

            int code = c.getResponseCode();

            if (code >= 200 && code < 300) {
                return new Result(true, code, "Đã đồng bộ với PostFlow.");
            }

            String error = readError(c);
            return new Result(false, code,
                    error.isEmpty() ? "Server từ chối Agent." : error);

        } catch (Exception e) {
            return new Result(false, -1,
                    e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static int countGroups(String json) {
        try {
            org.json.JSONArray a = new org.json.JSONArray(json == null ? "[]" : json);
            return a.length();
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static String enc(String s) throws Exception {
        return URLEncoder.encode(s == null ? "" : s, "UTF-8");
    }

    private static String readError(HttpURLConnection c) {
        try {
            InputStream in = c.getErrorStream();
            if (in == null) return "";
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) b.append(line);
            br.close();
            return b.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    public static final class Result {
        public final boolean ok;
        public final int code;
        public final String message;

        public Result(boolean ok, int code, String message) {
            this.ok = ok;
            this.code = code;
            this.message = message;
        }
    }
}
