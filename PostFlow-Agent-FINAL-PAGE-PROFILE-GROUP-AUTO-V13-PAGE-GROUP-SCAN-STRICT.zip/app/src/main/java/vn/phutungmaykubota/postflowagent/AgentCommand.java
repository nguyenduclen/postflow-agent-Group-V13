package vn.phutungmaykubota.postflowagent;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Small, user-controlled command bridge: Panel can ask the Agent to open a
 * Facebook URL in Chrome. It never handles passwords, cookies or page content.
 */
public final class AgentCommand {
    private AgentCommand() {}

    public static void pollAndExecute(Context context) {
        String token = AgentSync.token(context);
        if (token == null || token.trim().isEmpty()) return;

        HttpURLConnection c = null;
        try {
            URL u = new URL(AgentSync.server(context) + "/agent_command.php?action=claim");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(5000);
            c.setReadTimeout(8000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("X-Agent-Token", token);
            byte[] body = ("device_id=" + URLEncoder.encode(AgentSync.deviceId(context), "UTF-8"))
                    .getBytes("UTF-8");
            c.getOutputStream().write(body);
            c.getOutputStream().flush();

            int code = c.getResponseCode();
            if (code < 200 || code >= 300) return;

            String text = read(c.getInputStream());
            JSONObject root = new JSONObject(text);
            if (!root.optBoolean("ok", false)) return;
            JSONObject command = root.optJSONObject("command");
            if (command == null) return;

            final int commandId = command.optInt("id", 0);
            final String type = command.optString("type", "");
            JSONObject payload = command.optJSONObject("payload");

            if (commandId <= 0) return;

            if ("open_url".equals(type)) {
                String target = payload == null ? "" : payload.optString("url", "").trim();
                if (!target.matches("(?i)^https://(?:www\\.)?facebook\\.com(?:/.*)?$")) {
                    finish(context, commandId, false, "URL Facebook không hợp lệ", "");
                    return;
                }

                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(target));
                intent.setPackage("com.android.chrome");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                try {
                    context.startActivity(intent);
                    finish(context, commandId, true, "", "{\"opened\":true}");
                } catch (Exception chromeError) {
                    Intent fallback = new Intent(Intent.ACTION_VIEW, Uri.parse(target));
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        context.startActivity(fallback);
                        finish(context, commandId, true, "", "{\"opened\":true,\"fallback\":true}");
                    } catch (Exception e) {
                        finish(context, commandId, false, "Không mở được Chrome: " + e.getMessage(), "");
                    }
                }
            } else {
                finish(context, commandId, false, "Lệnh Agent không được hỗ trợ", "");
            }
        } catch (Exception ignored) {
            // Polling is best-effort; heartbeat/status remains independent.
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static void finish(Context context, int commandId, boolean success,
                               String error, String resultJson) {
        HttpURLConnection c = null;
        try {
            URL u = new URL(AgentSync.server(context) + "/agent_command.php?action=finish");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(5000);
            c.setReadTimeout(8000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("X-Agent-Token", AgentSync.token(context));

            String body = "command_id=" + commandId
                    + "&success=" + (success ? "1" : "0")
                    + "&error=" + URLEncoder.encode(error == null ? "" : error, "UTF-8")
                    + "&result_json=" + URLEncoder.encode(resultJson == null ? "" : resultJson, "UTF-8");
            c.getOutputStream().write(body.getBytes("UTF-8"));
            c.getOutputStream().flush();
            c.getResponseCode();
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String read(InputStream in) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder b = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close();
        return b.toString();
    }
}
